<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DropPointController extends Controller
{
    //
}
